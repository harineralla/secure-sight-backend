def test(smartcheck_api_key,qradar_api_key,qradr_url):
    # import PostScanEventsQradar
    # th = PostScanEventsQradar.PostScanEventsQradar()
    # th.run(smartcheck_api_key,qradar_api_key,qradr_url)
    
    import PostJsonEventsQradar
    th = PostJsonEventsQradar.PostJsonEventsQradar()
    th.run(smartcheck_api_key,qradar_api_key,qradr_url)
    
if __name__ == '__main__':
    import sys
    if len(sys.argv) == 4:
        test(sys.argv[1], sys.argv[2],sys.argv[3])
    else:
        print("Incorrect Command")
        print('python test_scans.py {smartcheck_api_key} {qradar_api_key} {qradr_url}')
