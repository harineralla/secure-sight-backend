To run the script:

`python test_scans.py {smartcheck_api_key} {qradar_api_key} {qradr_url}`

Sample run:

`python test_scans.py tmc12H7RSXH8VKVZvRTSBTe9kgWpPYH:3p1aNniwcL7he4xRAeftxobntTPqsZnxRGwnUgRcGJ825o3CWx8mgDGBTsMKFxc2ZE 07b1ab3e-294c-443f-abe6-7452b6143627 195.133.128.65:8443`
