import http.client
import json
from threading import Thread
import sys
import requests

class PostScanEventsQradar(Thread):
    def Container_Security_Scans(self,headers):
        r = requests.get("https://container.us-1.cloudone.trendmicro.com/api/scans", headers=headers,verify=False) #List Container_Security scans
        body = r.json()['scans']
        return body

    def Container_Security_Evaluation(self,headers):
        r = requests.get("https://container.us-1.cloudone.trendmicro.com/api/events/evaluations", headers=headers,verify=False) #List Container_Security evaluation events
        body = r.json()['events']
        return body

    def Container_Security_Audit(self,headers):
        r = requests.get("https://container.us-1.cloudone.trendmicro.com/api/events/audits", headers=headers,verify=False) #List Container_Security audit events
        body = r.json()['events']
        return body

    def Container_Security_RuntimeSensor(self,headers):
        r = requests.get("https://container.us-1.cloudone.trendmicro.com/api/events/sensors", headers=headers,verify=False) #List Container_Security runtime sensor events
        body = r.json()['events']
        return body


    ####################################
    #
    # Check if the map of sets exists
    # to store container security data
    #
    ####################################

    def Check_Map_Existence(self,qradar_api_key,qradar_url,set_name="deep_sec_data"):
        qradar_header = {
            'Accept':'application/json',
            'SEC': qradar_api_key,
            'Content-Type':'text/plain'
        }
        client = qradar_url
        url_suffix='/reference_data/map_of_sets?filter=name%3D' + set_name
        url = "https://"+qradar_url+"/api"+url_suffix

        response = requests.get(url,headers=qradar_header,verify=False)

        print(response.json())
        # Create Map if it doesn't exist
        if not response.json():
            self.Create_Map(qradar_api_key,qradar_url,set_name)

    def Create_Map(self,qradar_api_key,qradar_url,set_name="deep_sec_data"):
        params=dict(
            name=set_name,
            element_type="ALN",
            key_label="Stores the event data from container security"
        )
        qradar_header = {
            'Accept':'application/json',
            'SEC': qradar_api_key,
            'Content-Type':'text/plain'
        }
        url_suffix='/reference_data/map_of_sets'
        url = "https://"+qradar_url+"/api"+url_suffix

        

        response = requests.post(url,headers=qradar_header,verify=False,params=params)

        print(json.dumps(response.json(),indent=4))

    def Add_To_Qradar(self,container_sec_data,qradar_api_key,qradar_url,set_name="deep_sec_data"):
        self.Check_Map_Existence(qradar_api_key,qradar_url,set_name)
        qradar_header = {
            'Accept':'application/json',
            'SEC': qradar_api_key,
            'Content-Type':'text/plain'
        }
        ##############################################
        #
        # Setup Qradar Configuration for POST Request
        #
        ##############################################


        url_suffix='/reference_data/map_of_sets/bulk_load/' + set_name
        url = "https://"+qradar_url+"/api"+url_suffix

        body = container_sec_data

    
            
        json_object = json.dumps(body, indent=4)
        
        # Writing to sample.json
        with open(set_name + ".json", "w") as outfile:
            outfile.write(json_object)
            
        qradr_map_store_header = {
            'Accept':'application/json',
            'SEC': qradar_api_key,
            'Content-Type':'application/json'
        }

        ####################################################
        #
        # Store the result of conformity
        #
        ####################################################
        for data_point in body:
            response = requests.post(url,headers=qradr_map_store_header,verify=False,json=data_point)
            print(json.dumps(response.json(),indent=4))

            if response.status_code == 200:
                print({"response_code": response.status_code,"data": response})
                print(response.json())
            else:
                print({"response_code": response.status_code, "data": []})

    def format_scans(self,scans):
        modified_scans = []
        for scan in scans:
            temp = scan['scan']
            del temp['source']
            del temp['context']
            del temp['findings']
            del temp['details']
            del temp['extendedResult']
            temp['source'] = scan['scan']['source']['registry']
            temp['malware'] = scan['scan']['findings']['malware']
            modified_scans.append(temp)
        return modified_scans

    def format_evaluations(self,evals):
        modified_evals = []
        for eval in evals:
            temp = eval
            del temp['reasons']
            del temp['expectations']
            modified_evals.append(temp)
        return modified_evals

    def format_audits(self,audits):
        modified_audits = []
        for audit in audits:
            temp = audit
            del temp['resources']
            modified_audits.append(temp)
        return modified_audits

    def format_sensor_events(self,sensor_events):
        modified_sensor_events = []
        for sensor_event in sensor_events:
            temp = sensor_event
            del temp['rulesets']
            del temp['k8s.pod.labels']
            del temp['metadata']
            del temp['tags']
            modified_sensor_events.append(temp)
        return modified_sensor_events
    
    def convert_to_csv_values(body):
        header = ""
        values = ""
        for key,value in body.items():
            header += key + ","
            values += value + ","

        return header,values
    
    def run(self,smartcheck_api_key,qradar_api_key,qradar_url):
        headers = { 'Authorization': f"ApiKey " + smartcheck_api_key, "Content-Type": "application/vnd.api+json" }

        try:
            body = self.Container_Security_Scans(headers)
            
            if body:
                self.Add_To_Qradar(self.format_scans(body),qradar_api_key,qradar_url,"ConatinerSecScans")
            else:
                print("No scan data")
        except:
            print("Oops!", sys.exc_info()[0], "occurred.")

        try:    
            body = self.Container_Security_Evaluation(headers)
            
            if body:
                self.Add_To_Qradar(self.format_evaluations(body),qradar_api_key,qradar_url,"ContainerSecEvaluations")
            else:
                print("No evaluation data")
        except:
            print("Oops!", sys.exc_info()[0], "occurred.")
        

        try:
            body = self.Container_Security_Audit(headers)
            
            if body:
                self.Add_To_Qradar(self.format_audits(body),qradar_api_key,qradar_url,"ContainerSecAudits")
        except:
            print("Oops!", sys.exc_info()[0], "occurred.")

        try:
            body = self.Container_Security_RuntimeSensor(headers)
            
            if body:
                self.Add_To_Qradar(self.format_sensor_events(body),qradar_api_key,qradar_url,"ContainerSecRuntimes")
        except:
            print("Oops!", sys.exc_info()[0], "occurred.")
            
        print({"data":["All done"]})

if (__name__ == '__main__'):
    print('Module => Do not execute')