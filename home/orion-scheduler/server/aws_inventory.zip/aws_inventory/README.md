To run the script
python test_aws.py {accid} {accsecret}

Sample run:
python test_aws.py AKIAUGGKIDDEBIMNDORG cBBz1fo3J9Eh2Iy2cnddC7t6BJBDWusJJKuwt++e